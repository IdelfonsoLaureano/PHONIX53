
# What is Tool-X ?

Tool-X is a kali linux hacking Tool installer for android. Tool-X is Developed By Rajkumar Dusad. with the help of Tool-X you can install best tools in termux app on android. In the Tool-X there are almost 70 hacking tools available for termux app and GNURoot Debian terminal. you can install any tool by single click. Tool-X is Specially made for Termux and GNURoot Debian Terminal.
<br/><br/><br/>

# Features

Install any tools by single click. You can install almost 70 tools in termux and GNURoot Debian Terminal.
<br/></br>

<p align="center">
<img src="https://github.com/Rajkumrdusad/Tool-X/blob/master/.sc/Tool-X.jpg"/>
</p>

<br/><br/><br/>

# How to use ?

- Type 0 : To install all tools.
- Type 1 : to sow all available tools and type the number of a tool which you want to install.
- Type 2 : if you want to update Tool-X.
- Type 3 : if you know About us.
- Type x : for exit.

<br/><br/><br/>

# Warning

## I am not expert so use this tool at your own risk.

<br/><br/><br/>

# How to Install in termux ?

Open the termux app and type following commands.

* `apt update`

* `pkg install git`

* `git clone https://github.com/Rajkumrdusad/Tool-X.git`

* `cd Tool-X`

* `chmod +x install.aex`

* `sh install.aex` if not work than type `./install.aex`

<br/>

## Now Tool-X is installed successfully. To run Tool-X Type

Now type Tool-X from anywhare in your terminl to open Tool-X.

<br/><br/><br/>

# How to Install in GNURoot Debian Terminal ?

Open the GNURoot Debian app and type following commands.

* `cd`

* `apt update`

* `apt upgrade`

* `apt install git`

* `cd && git clone https://github.com/Rajkumrdusad/Tool-X.git`

* `cd Tool-X`

* `chmod +x install.aex`

* `sh install.aex` if not work than type `./install.aex`

<br/>

## Now Tool-X is installed successfully. To run Tool-X Type

Now type Tool-X from anywhare in your terminl to open Tool-X. But use this tool only for legal purpose.

